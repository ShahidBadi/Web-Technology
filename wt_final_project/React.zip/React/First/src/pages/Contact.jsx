import { Component } from "react"
function Contact(){
    return(
        <>
            <h1>Welcome to Contact page</h1>
        </>
    )
}

export default Contact