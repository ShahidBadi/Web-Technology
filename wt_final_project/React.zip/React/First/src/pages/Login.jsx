import { Component } from "react"
function Login(){
    return(
        <>
            <h1>Welcome to Login page</h1>
        </>
    )
}

export default Login