import { Component } from "react"
function About(){
    return(
        <>
            <h1>Welcome to About page</h1>
        </>
    )
}

export default About