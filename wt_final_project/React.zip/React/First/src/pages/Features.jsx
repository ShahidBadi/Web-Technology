import { Component } from "react"
function Features(){
    return(
        <>
            <h1>Welcome to Features page</h1>
        </>
    )
}

export default Features